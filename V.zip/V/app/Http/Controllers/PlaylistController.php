<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateRequest;
use App\Http\Requests\ReadRequest;
use App\Models\PlayList;
use Illuminate\Http\JsonResponse;

class PlaylistController extends Controller
{
    public function store(CreateRequest $request): JsonResponse
    {
        $play_list = new PlayList();
        $play_list->name = $request->name;
        $play_list->user_id = $request->user_id;
        $play_list->max_items = $request->max_items;
        if ($play_list->save()) {
            return response()->json(["status" => "OK"]);
        }

        return response()->json(["status" => "FAIL"], 500);
    }

    public function read(ReadRequest $request): JsonResponse
    {
        return response()->json([
            "playlist" => PlayList::where("user_id", $request->user_id)->get()
        ]);
    }

    public function delete($playListId): JsonResponse
    {
        return response()->json([
            "result" => PlayList::find($playListId)->delete()
        ]);
    }

}
