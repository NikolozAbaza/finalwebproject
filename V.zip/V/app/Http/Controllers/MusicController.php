<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateMusicRequest;
use App\Http\Requests\ReadRequest;
use App\Models\Music;
use App\Models\Playlist;
use Illuminate\Http\JsonResponse;

class MusicController extends Controller
{
    public function store(CreateMusicRequest $request, $playlistId): JsonResponse
    {
        Playlist::findOrFail($playlistId);

        $music = new Music();
        $music->music_name = $request->music_name;
        $music->music_url = $request->music_url;
        $music->playlist_id = $playlistId;
        if ($music->save())
            return response()->json(["status" => "OK"]);

        return response()->json(["status" => "FAIL"]);
    }

    public function read(ReadRequest $request): JsonResponse
    {
        $playlist = Playlist::where("user_id", $request->user_id)->first();
        return response()->json([
            "musics" => $playlist->songs
        ]);
    }

    public function delete($music_id): JsonResponse
    {
        return response()->json([
            "result" => Music::find($music_id)->delete()
        ]);
    }

}
